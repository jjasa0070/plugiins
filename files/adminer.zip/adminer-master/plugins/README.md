Plugins directory including external plugins: https://www.adminer.org/plugins/

## Screenshot
![screenshot](https://www.adminer.org/static/designs/bueltge/screenshot.png)

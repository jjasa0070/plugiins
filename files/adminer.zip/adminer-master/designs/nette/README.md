## Screenshot
![screenshot](https://www.adminer.org/static/designs/nette/screenshot.png)

<?php
namespace Adminer;

const VERSION = "5.3.1-dev";

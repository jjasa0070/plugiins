## Screenshot
![screenshot](https://www.adminer.org/static/designs/win98/screenshot.png)

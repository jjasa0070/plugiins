<?php
namespace Adminer;

connection()->select_db(adminer()->database());
